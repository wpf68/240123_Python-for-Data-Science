
Creation d'un package :

https://python.doctor/page-python-modules-package-module-cours-debutants-informatique-programmation

https://geekflare.com/fr/create-python-packages/

